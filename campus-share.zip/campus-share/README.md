# 📚 Campus Share – Campus Resource Sharing Platform

Students can **lend, borrow and exchange** books, calculators, electronics and more within their college.
Every user gets a **Trust Score** built from how reliably they return items and what other students say about them.

## Features

| Requirement | How it works |
|---|---|
| Registration with college email | Only emails on allowed domains can register (`ALLOWED_EMAIL_DOMAINS` in `.env`) |
| List items for borrowing | **My Items** tab – title, category, condition, description; hide/show or delete |
| Search books, calculators, electronics… | **Browse** tab – text search + category filter |
| Request to borrow | Pick a return date and send a message to the owner |
| Owner approval / rejection | **Requests for me** tab – approve or reject (a red badge shows pending count) |
| Return date tracking | Due dates shown everywhere, **Overdue** flag, owner marks item *returned* (on-time or late is recorded) |
| Borrowing history | **History** tab – every finished transaction as lender or borrower |
| Ratings and reviews | After a return, both sides can review each other once (1–5 stars + comment) |
| **Trust score** | 0–100 score shown on items, requests and profiles |

### Trust score formula

```
trust = 100 × ( 0.6 × returnScore + 0.4 × reviewScore )

returnScore = (onTimeReturns + 1) / (completedReturns + 2)
reviewScore = ((sumOfRatings + 2.5×2) / (reviewCount + 2)) / 5
```

* New users start at **50**. Smoothing stops one transaction from swinging the score to an extreme.
* Every on-time return and every good review pushes it up; late returns and poor reviews pull it down.
* Levels: `New` (fewer than 3 data points), `Low` (<40), `Fair` (40–59), `Trusted` (60–79), `Highly trusted` (80+).
* Code: [`src/trust.js`](src/trust.js)

## Tech stack

Node.js · Express · SQLite (`better-sqlite3`) · JWT auth (`jsonwebtoken` + `bcryptjs`) · vanilla HTML/CSS/JS frontend (no build step)

## Run it

Requires **Node.js 18+**.

```bash
npm install
cp .env.example .env      # Windows: copy .env.example .env   then edit JWT_SECRET
npm start                 # or: npm run dev  (auto-restart on change)
```

Open <http://localhost:3000>, register with an email on an allowed domain (default: `.edu`, `.ac.in`, `.edu.in`), and try it with two accounts in two browsers (one lends, one borrows).

Run the automated end-to-end test:

```bash
npm test
```

## Project structure

```
campus-share/
├── src/
│   ├── server.js          # starts the server
│   ├── app.js             # Express app + routes wiring
│   ├── db.js              # SQLite schema
│   ├── auth.js            # JWT + college-email check
│   ├── trust.js           # trust score logic
│   └── routes/            # auth, users, items, requests, reviews
├── public/                # frontend (index.html, app.js, style.css)
├── test/smoke.test.js     # full borrow → return → review → trust test
└── .env.example
```

## API summary

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register`, `/api/auth/login` | Account |
| GET | `/api/users/me`, `/api/users/:id` | Profile + trust score + reviews |
| GET | `/api/items?q=&category=` | Search items |
| GET/POST | `/api/items/mine`, `/api/items` | Manage own items |
| PATCH/DELETE | `/api/items/:id` | Edit / hide / delete |
| POST | `/api/requests` | Request to borrow |
| GET | `/api/requests?view=incoming\|outgoing\|history` | Lists |
| POST | `/api/requests/:id/approve\|reject\|cancel\|return` | Workflow |
| POST | `/api/reviews` | Review the other party after return |

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Campus Share"
git branch -M main
git remote add origin https://github.com/<your-username>/campus-share.git
git push -u origin main
```

(Create the empty `campus-share` repository on github.com first. `.env`, `node_modules` and the database file are already in `.gitignore`.)

## Ideas to extend

* Email verification link (e.g. with Nodemailer) instead of domain check only
* Item photos (Multer upload) and in-app chat between borrower and owner
* Late-return reminders by email, deposit/points system
* Swap to PostgreSQL / deploy on Render or Railway

## Known limitations

Email ownership is not verified (only the domain is checked), and there is no rate limiting – add both before a real deployment.

## License

MIT
