/* Campus Share - single-page frontend (no build step, plain JS) */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let token = localStorage.getItem('cs_token');
let me = null;
let registerMode = false;
let currentTab = 'browse';

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) { logout(); }
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function toast(msg, isErr = false) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'toast' + (isErr ? ' err' : ''); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), 3000);
}
const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

/* ---------- helpers ---------- */
function trustBadge(t) {
  const color = t.score >= 70 ? 'var(--good)' : t.score >= 45 ? 'var(--warn)' : 'var(--bad)';
  return `<span class="trust" title="${esc(t.level)}: ${t.onTimeReturns}/${t.completedReturns} on-time returns, ${t.reviewCount} reviews">
    🛡 ${t.score}<span class="bar"><i style="width:${t.score}%;background:${color}"></i></span>
    <span class="muted">${esc(t.level)}</span></span>`;
}
const stars = (n) => `<span class="stars">${'★'.repeat(n)}${'☆'.repeat(5 - n)}</span>`;
const fmtDate = (s) => (s ? new Date(s.replace(' ', 'T') + (s.length > 10 ? 'Z' : '')).toLocaleDateString() : '');
const statusPill = (r) => {
  if (r.overdue) return '<span class="pill bad">Overdue</span>';
  const map = { pending: 'warn', approved: 'good', returned: '', rejected: 'bad', cancelled: 'grey' };
  const label = r.status === 'approved' ? 'Lent out' : r.status;
  return `<span class="pill ${map[r.status] || ''}">${esc(label)}</span>`;
};

/* ---------- navigation ---------- */
function show(view) {
  $$('main > section').forEach((s) => (s.hidden = s.id !== 'view-' + view));
}
function setTab(tab) {
  currentTab = tab;
  $$('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  show(tab);
  loaders[tab]?.().catch((e) => toast(e.message, true));
}
$('#nav').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setTab(b.dataset.tab); });

/* ---------- auth ---------- */
function renderAuth() {
  $('#auth-title').textContent = registerMode ? 'Create account' : 'Log in';
  $('#name-wrap').hidden = !registerMode;
  $('#auth-switch').textContent = registerMode ? 'Have an account? Log in' : 'Need an account? Register';
}
$('#auth-switch').onclick = (e) => { e.preventDefault(); registerMode = !registerMode; renderAuth(); };
$('#auth-form').onsubmit = guard(async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const out = await api(registerMode ? '/auth/register' : '/auth/login', { method: 'POST', body: f });
  token = out.token; localStorage.setItem('cs_token', token);
  await boot();
});
function logout() {
  token = null; me = null; localStorage.removeItem('cs_token');
  $('#nav').hidden = true; $('#me').hidden = true; show('auth');
}
$('#logout').onclick = logout;
$('#me-link').onclick = guard(async (e) => { e.preventDefault(); await openProfile(me.id); });

/* ---------- modal ---------- */
function modal(html, onSubmit) {
  const d = $('#modal'), f = $('#modal-body');
  f.innerHTML = html;
  f.onsubmit = guard(async (e) => {
    if (e.submitter?.value === 'cancel') return;
    e.preventDefault();
    await onSubmit(Object.fromEntries(new FormData(f)));
    d.close();
  });
  d.showModal();
}

/* ---------- browse ---------- */
async function loadCategories() {
  const cats = await api('/items/categories');
  $('#cat').innerHTML = '<option value="">All categories</option>' + cats.map((c) => `<option>${esc(c)}</option>`).join('');
  $('#item-cat').innerHTML = cats.map((c) => `<option>${esc(c)}</option>`).join('');
}
async function loadBrowse() {
  const q = encodeURIComponent($('#q').value), c = encodeURIComponent($('#cat').value);
  const items = await api(`/items?q=${q}&category=${c}`);
  $('#browse-list').innerHTML = items.length
    ? items.map((i) => {
        const mineItem = i.owner_id === me.id;
        return `<article class="card item">
          <h3>${esc(i.title)}</h3>
          <div class="muted">${esc(i.description)}</div>
          <div class="meta"><span class="pill">${esc(i.category)}</span><span class="pill grey">${esc(i.condition)}</span>
            ${i.lent_out ? `<span class="pill warn">Back ${esc(i.due_back)}</span>` : '<span class="pill good">Available</span>'}</div>
          <div>by <a href="#" data-profile="${i.owner_id}">${esc(i.owner_name)}</a> ${trustBadge(i.owner_trust)}</div>
          <div class="actions">${mineItem ? '<span class="muted">Your item</span>'
            : `<button class="primary" data-borrow="${i.id}" data-title="${esc(i.title)}" ${i.lent_out ? 'disabled' : ''}>Request to borrow</button>`}</div>
        </article>`;
      }).join('')
    : '<div class="empty">No items found. Be the first to list something!</div>';
}
$('#q').oninput = () => { clearTimeout(loadBrowse.t); loadBrowse.t = setTimeout(() => loadBrowse().catch((e) => toast(e.message, true)), 250); };
$('#cat').onchange = () => loadBrowse().catch((e) => toast(e.message, true));
$('#browse-list').addEventListener('click', (e) => {
  const p = e.target.closest('[data-profile]');
  if (p) { e.preventDefault(); return openProfile(p.dataset.profile); }
  const b = e.target.closest('[data-borrow]');
  if (!b) return;
  const min = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  modal(`<h3>Borrow “${esc(b.dataset.title)}”</h3>
    <label>Return by <input type="date" name="dueDate" min="${min}" required></label>
    <label>Message to owner <input name="message" placeholder="Why do you need it? (optional)"></label>
    <div class="modal-actions"><button value="cancel" class="ghost" formnovalidate>Cancel</button><button class="primary">Send request</button></div>`,
    async (v) => { await api('/requests', { method: 'POST', body: { itemId: Number(b.dataset.borrow), ...v } }); toast('Request sent!'); setTab('outgoing'); });
});

/* ---------- my items ---------- */
async function loadMine() {
  const items = await api('/items/mine');
  $('#mine-list').innerHTML = items.length
    ? items.map((i) => `<article class="card item">
        <h3>${esc(i.title)}</h3><div class="muted">${esc(i.description)}</div>
        <div class="meta"><span class="pill">${esc(i.category)}</span><span class="pill grey">${esc(i.condition)}</span>
          ${i.lent_out ? `<span class="pill warn">Lent out · due ${esc(i.due_back)}</span>` : i.listed ? '<span class="pill good">Listed</span>' : '<span class="pill grey">Hidden</span>'}</div>
        <div class="actions">
          <button class="ghost" data-toggle="${i.id}" data-listed="${i.listed ? 0 : 1}">${i.listed ? 'Hide' : 'Show'}</button>
          <button class="danger" data-del="${i.id}">Delete</button></div>
      </article>`).join('')
    : '<div class="empty">You have not listed anything yet.</div>';
}
$('#item-form').onsubmit = guard(async (e) => {
  e.preventDefault();
  await api('/items', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
  e.target.reset(); toast('Item listed'); loadMine();
});
$('#mine-list').addEventListener('click', guard(async (e) => {
  const t = e.target.closest('[data-toggle]'), d = e.target.closest('[data-del]');
  if (t) { await api('/items/' + t.dataset.toggle, { method: 'PATCH', body: { listed: t.dataset.listed === '1' } }); loadMine(); }
  if (d && confirm('Delete this item?')) { await api('/items/' + d.dataset.del, { method: 'DELETE' }); loadMine(); }
}));

/* ---------- requests ---------- */
function reqCard(r, view) {
  const other = view === 'incoming' ? `from <a href="#" data-profile="${r.borrower_id}">${esc(r.borrower_name)}</a> ${r.borrower_trust ? trustBadge(r.borrower_trust) : ''}`
    : `owner <a href="#" data-profile="${r.owner_id}">${esc(r.owner_name)}</a>`;
  let actions = '';
  if (view === 'incoming' && r.status === 'pending')
    actions = `<button class="ok" data-act="approve" data-id="${r.id}">Approve</button><button class="danger" data-act="reject" data-id="${r.id}">Reject</button>`;
  if (view === 'incoming' && r.status === 'approved')
    actions = `<button class="primary" data-act="return" data-id="${r.id}">Mark as returned</button>`;
  if (view === 'outgoing' && r.status === 'pending')
    actions = `<button class="ghost" data-act="cancel" data-id="${r.id}">Cancel request</button>`;
  if (view === 'history' && r.status === 'returned' && !r.reviewed_by_me)
    actions = `<button class="primary" data-review="${r.id}" data-who="${esc(r.owner_id === me.id ? r.borrower_name : r.owner_name)}">Leave a review</button>`;
  const returnedInfo = r.status === 'returned'
    ? `<div class="muted">Returned ${fmtDate(r.returned_at)} · ${r.on_time ? '✅ on time' : '⚠️ late'}</div>` : '';
  return `<article class="card req"><div class="info">
      <h3>${esc(r.item_title)} ${statusPill(r)}</h3>
      <div>${other}${view === 'history' ? ` · you were the <b>${r.owner_id === me.id ? 'lender' : 'borrower'}</b>` : ''}</div>
      <div class="muted">Due ${esc(r.due_date)} · requested ${fmtDate(r.requested_at)}</div>
      ${r.message ? `<div class="muted">“${esc(r.message)}”</div>` : ''}${returnedInfo}</div>
      <div class="actions">${actions}</div></article>`;
}
const loadView = (view) => async () => {
  const list = await api('/requests?view=' + view);
  const empty = { incoming: 'No requests waiting for you.', outgoing: "You aren't borrowing anything right now.", history: 'No finished transactions yet.' }[view];
  $(`#${view}-list`).innerHTML = list.length ? list.map((r) => reqCard(r, view)).join('') : `<div class="empty">${empty}</div>`;
  if (view === 'incoming') {
    const n = list.filter((r) => r.status === 'pending').length;
    $('#badge-in').hidden = !n; $('#badge-in').textContent = n;
  }
};
['incoming', 'outgoing', 'history'].forEach((v) => {
  $(`#${v}-list`).addEventListener('click', guard(async (e) => {
    const p = e.target.closest('[data-profile]');
    if (p) { e.preventDefault(); return openProfile(p.dataset.profile); }
    const a = e.target.closest('[data-act]');
    if (a) { await api(`/requests/${a.dataset.id}/${a.dataset.act}`, { method: 'POST' }); toast('Done'); return setTab(currentTab); }
    const r = e.target.closest('[data-review]');
    if (r) openReview(r.dataset.review, r.dataset.who);
  }));
});

function openReview(requestId, who) {
  modal(`<h3>Review ${esc(who)}</h3>
    <div class="star-pick" id="stars">${[1, 2, 3, 4, 5].map((n) => `<span data-n="${n}">★</span>`).join('')}</div>
    <input type="hidden" name="rating" value="0">
    <label>Comment <input name="comment" placeholder="How did it go?"></label>
    <div class="modal-actions"><button value="cancel" class="ghost" formnovalidate>Cancel</button><button class="primary">Submit</button></div>`,
    async (v) => {
      if (!Number(v.rating)) throw new Error('Pick a star rating first.');
      await api('/reviews', { method: 'POST', body: { requestId: Number(requestId), rating: Number(v.rating), comment: v.comment } });
      toast('Review saved. Thank you!'); setTab('history');
    });
  $('#stars').onclick = (e) => {
    const s = e.target.closest('[data-n]'); if (!s) return;
    $('#modal-body [name=rating]').value = s.dataset.n;
    $$('#stars span').forEach((x) => x.classList.toggle('on', +x.dataset.n <= +s.dataset.n));
  };
}

/* ---------- profile ---------- */
async function openProfile(id) {
  const u = await api('/users/' + id);
  $$('#nav button').forEach((b) => b.classList.remove('active'));
  show('profile');
  const t = u.trust;
  $('#profile').innerHTML = `
    <div class="profile-head"><div class="big-score">🛡 ${t.score}</div>
      <div><h2>${esc(u.name)}</h2>${trustBadge(t)}
      <div class="muted">${t.onTimeReturns}/${t.completedReturns} items returned on time · ${t.reviewCount} reviews${t.avgRating ? ` · avg ${t.avgRating}★` : ''}</div></div></div>
    <h3 style="margin-top:1.2rem">Reviews</h3>
    ${u.reviews.length ? u.reviews.map((r) => `<div class="review">${stars(r.rating)} <b>${esc(r.reviewer)}</b> <span class="muted">on “${esc(r.item)}” · ${fmtDate(r.created_at)}</span>
      ${r.comment ? `<div>${esc(r.comment)}</div>` : ''}</div>`).join('') : '<div class="muted">No reviews yet.</div>'}
    <p class="muted" style="margin-top:1rem">Trust score = 60% on-time returns + 40% average review rating. New users start at 50.</p>`;
}

/* ---------- boot ---------- */
const loaders = { browse: loadBrowse, mine: loadMine, incoming: loadView('incoming'), outgoing: loadView('outgoing'), history: loadView('history') };

async function boot() {
  if (!token) { renderAuth(); return show('auth'); }
  try { me = await api('/users/me'); } catch { return logout(); }
  $('#nav').hidden = false; $('#me').hidden = false;
  $('#me-link').innerHTML = `${esc(me.name)} · 🛡 ${me.trust.score}`;
  await loadCategories();
  loaders.incoming().catch(() => {}); // fills the pending badge
  setTab('browse');
}
boot();
