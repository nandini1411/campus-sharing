const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

function sign(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, SECRET, { expiresIn: '7d' });
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Please log in.' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
}

/** Is this email on an allowed college domain? */
function isCollegeEmail(email) {
  const allowed = (process.env.ALLOWED_EMAIL_DOMAINS || 'edu,ac.in,edu.in')
    .split(',')
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);
  const domain = String(email).toLowerCase().split('@')[1];
  if (!domain) return false;
  return allowed.some((d) => domain === d || domain.endsWith('.' + d));
}

module.exports = { sign, requireAuth, isCollegeEmail };
