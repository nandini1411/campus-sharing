const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { sign, isCollegeEmail } = require('../auth');
const { computeTrust } = require('../trust');

const router = express.Router();

router.post('/register', (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (name.length < 2) return res.status(400).json({ error: 'Please enter your name.' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email.' });
  if (!isCollegeEmail(email))
    return res.status(400).json({ error: 'Please register with your college email address.' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });

  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email))
    return res.status(409).json({ error: 'This email is already registered.' });

  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    .run(name, email, hash);
  const user = { id: info.lastInsertRowid, name, email };
  res.status(201).json({ token: sign(user), user: { ...user, trust: computeTrust(user.id) } });
});

router.post('/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row || !bcrypt.compareSync(password, row.password_hash))
    return res.status(401).json({ error: 'Wrong email or password.' });
  const user = { id: row.id, name: row.name, email: row.email };
  res.json({ token: sign(user), user: { ...user, trust: computeTrust(user.id) } });
});

module.exports = router;
