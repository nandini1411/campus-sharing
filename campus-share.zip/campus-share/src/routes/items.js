const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');
const { computeTrust } = require('../trust');

const router = express.Router();
router.use(requireAuth);

const CATEGORIES = ['Books', 'Calculators', 'Electronics', 'Lab Equipment', 'Stationery', 'Sports', 'Other'];

// "available now" = listed and not currently lent out
const ITEM_SELECT = `
  SELECT i.*, u.name AS owner_name,
         EXISTS (SELECT 1 FROM requests r WHERE r.item_id = i.id AND r.status = 'approved') AS lent_out,
         (SELECT due_date FROM requests r WHERE r.item_id = i.id AND r.status = 'approved') AS due_back
    FROM items i JOIN users u ON u.id = i.owner_id`;

function decorate(row) {
  return { ...row, lent_out: !!row.lent_out, listed: !!row.listed, owner_trust: computeTrust(row.owner_id) };
}

router.get('/categories', (req, res) => res.json(CATEGORIES));

// Search / browse other students' items
router.get('/', (req, res) => {
  const q = String(req.query.q || '').trim();
  const category = String(req.query.category || '').trim();
  const params = [];
  let where = 'WHERE i.listed = 1';
  if (q) {
    where += ' AND (i.title LIKE ? OR i.description LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  if (category) {
    where += ' AND i.category = ?';
    params.push(category);
  }
  const rows = db.prepare(`${ITEM_SELECT} ${where} ORDER BY i.created_at DESC LIMIT 200`).all(...params);
  res.json(rows.map(decorate));
});

router.get('/mine', (req, res) => {
  const rows = db
    .prepare(`${ITEM_SELECT} WHERE i.owner_id = ? ORDER BY i.created_at DESC`)
    .all(req.user.id);
  res.json(rows.map(decorate));
});

router.post('/', (req, res) => {
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const category = CATEGORIES.includes(req.body.category) ? req.body.category : 'Other';
  const condition = ['New', 'Good', 'Fair', 'Worn'].includes(req.body.condition) ? req.body.condition : 'Good';
  if (title.length < 2) return res.status(400).json({ error: 'Give the item a title.' });
  if (title.length > 100) return res.status(400).json({ error: 'Title is too long.' });

  const info = db
    .prepare('INSERT INTO items (owner_id, title, description, category, condition) VALUES (?, ?, ?, ?, ?)')
    .run(req.user.id, title, description.slice(0, 1000), category, condition);
  const row = db.prepare(`${ITEM_SELECT} WHERE i.id = ?`).get(info.lastInsertRowid);
  res.status(201).json(decorate(row));
});

// Edit / hide / show
router.patch('/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (item.owner_id !== req.user.id) return res.status(403).json({ error: 'Not your item.' });

  const title = req.body.title !== undefined ? String(req.body.title).trim() : item.title;
  const description = req.body.description !== undefined ? String(req.body.description).trim() : item.description;
  const category = CATEGORIES.includes(req.body.category) ? req.body.category : item.category;
  const listed = req.body.listed !== undefined ? (req.body.listed ? 1 : 0) : item.listed;
  if (title.length < 2) return res.status(400).json({ error: 'Give the item a title.' });

  db.prepare('UPDATE items SET title=?, description=?, category=?, listed=? WHERE id=?')
    .run(title, description.slice(0, 1000), category, listed, item.id);
  res.json(decorate(db.prepare(`${ITEM_SELECT} WHERE i.id = ?`).get(item.id)));
});

router.delete('/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (item.owner_id !== req.user.id) return res.status(403).json({ error: 'Not your item.' });
  const hasHistory = db.prepare('SELECT 1 FROM requests WHERE item_id = ?').get(item.id);
  if (hasHistory)
    return res.status(409).json({ error: 'This item has borrowing history, so it can only be hidden, not deleted.' });
  db.prepare('DELETE FROM items WHERE id = ?').run(item.id);
  res.json({ ok: true });
});

module.exports = router;
