const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');
const { computeTrust } = require('../trust');

const router = express.Router();
router.use(requireAuth);

const today = () => new Date().toISOString().slice(0, 10);
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s));

const REQ_SELECT = `
  SELECT q.*, i.title AS item_title, i.category AS item_category,
         b.name AS borrower_name, o.name AS owner_name,
         (q.status = 'approved' AND q.due_date < date('now')) AS overdue,
         EXISTS (SELECT 1 FROM reviews rv WHERE rv.request_id = q.id AND rv.reviewer_id = @me) AS reviewed_by_me
    FROM requests q
    JOIN items i ON i.id = q.item_id
    JOIN users b ON b.id = q.borrower_id
    JOIN users o ON o.id = q.owner_id`;

function shape(row) {
  return { ...row, overdue: !!row.overdue, reviewed_by_me: !!row.reviewed_by_me };
}

/**
 * GET /api/requests?view=
 *   incoming - requests for MY items that still need action (pending / approved)
 *   outgoing - requests I made that are still active (pending / approved)
 *   history  - everything finished (returned / rejected / cancelled), both roles
 */
router.get('/', (req, res) => {
  const me = req.user.id;
  const view = req.query.view || 'outgoing';
  let where, order = 'q.requested_at DESC';
  if (view === 'incoming') where = "q.owner_id = @me AND q.status IN ('pending','approved')";
  else if (view === 'history')
    where = "(q.owner_id = @me OR q.borrower_id = @me) AND q.status IN ('returned','rejected','cancelled')";
  else where = "q.borrower_id = @me AND q.status IN ('pending','approved')";

  const rows = db.prepare(`${REQ_SELECT} WHERE ${where} ORDER BY ${order}`).all({ me });
  const out = rows.map((r) => {
    const s = shape(r);
    if (view === 'incoming') s.borrower_trust = computeTrust(r.borrower_id);
    return s;
  });
  res.json(out);
});

// Ask to borrow an item
router.post('/', (req, res) => {
  const itemId = Number(req.body.itemId);
  const dueDate = String(req.body.dueDate || '');
  const message = String(req.body.message || '').trim().slice(0, 500);

  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(itemId);
  if (!item || !item.listed) return res.status(404).json({ error: 'Item not available.' });
  if (item.owner_id === req.user.id) return res.status(400).json({ error: "You can't borrow your own item." });
  if (!isDate(dueDate) || dueDate <= today())
    return res.status(400).json({ error: 'Choose a return date in the future.' });
  const maxDays = 60;
  if ((Date.parse(dueDate) - Date.parse(today())) / 86400000 > maxDays)
    return res.status(400).json({ error: `Maximum borrowing period is ${maxDays} days.` });

  if (db.prepare("SELECT 1 FROM requests WHERE item_id = ? AND status = 'approved'").get(itemId))
    return res.status(409).json({ error: 'This item is currently lent out.' });
  if (db.prepare("SELECT 1 FROM requests WHERE item_id = ? AND borrower_id = ? AND status = 'pending'")
        .get(itemId, req.user.id))
    return res.status(409).json({ error: 'You already have a pending request for this item.' });

  const info = db
    .prepare('INSERT INTO requests (item_id, borrower_id, owner_id, message, due_date) VALUES (?, ?, ?, ?, ?)')
    .run(itemId, req.user.id, item.owner_id, message, dueDate);
  res.status(201).json(shape(db.prepare(`${REQ_SELECT} WHERE q.id = @id`).get({ id: info.lastInsertRowid, me: req.user.id })));
});

function load(req, res) {
  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id);
  if (!r) { res.status(404).json({ error: 'Request not found.' }); return null; }
  return r;
}
const reply = (req, id) => shape(db.prepare(`${REQ_SELECT} WHERE q.id = @id`).get({ id, me: req.user.id }));

// Owner approves
router.post('/:id/approve', (req, res) => {
  const r = load(req, res); if (!r) return;
  if (r.owner_id !== req.user.id) return res.status(403).json({ error: 'Only the owner can approve.' });
  if (r.status !== 'pending') return res.status(409).json({ error: `Request is already ${r.status}.` });
  if (db.prepare("SELECT 1 FROM requests WHERE item_id = ? AND status = 'approved'").get(r.item_id))
    return res.status(409).json({ error: 'This item is already lent to someone else.' });
  db.prepare("UPDATE requests SET status='approved', decided_at=datetime('now') WHERE id=?").run(r.id);
  res.json(reply(req, r.id));
});

// Owner rejects
router.post('/:id/reject', (req, res) => {
  const r = load(req, res); if (!r) return;
  if (r.owner_id !== req.user.id) return res.status(403).json({ error: 'Only the owner can reject.' });
  if (r.status !== 'pending') return res.status(409).json({ error: `Request is already ${r.status}.` });
  db.prepare("UPDATE requests SET status='rejected', decided_at=datetime('now') WHERE id=?").run(r.id);
  res.json(reply(req, r.id));
});

// Borrower cancels a pending request
router.post('/:id/cancel', (req, res) => {
  const r = load(req, res); if (!r) return;
  if (r.borrower_id !== req.user.id) return res.status(403).json({ error: 'Only the borrower can cancel.' });
  if (r.status !== 'pending') return res.status(409).json({ error: 'Only pending requests can be cancelled.' });
  db.prepare("UPDATE requests SET status='cancelled', decided_at=datetime('now') WHERE id=?").run(r.id);
  res.json(reply(req, r.id));
});

// Owner confirms the item came back -> return date tracking + trust score input
router.post('/:id/return', (req, res) => {
  const r = load(req, res); if (!r) return;
  if (r.owner_id !== req.user.id) return res.status(403).json({ error: 'Only the owner can confirm a return.' });
  if (r.status !== 'approved') return res.status(409).json({ error: 'This item is not currently lent out.' });
  const onTime = today() <= r.due_date ? 1 : 0;
  db.prepare("UPDATE requests SET status='returned', returned_at=datetime('now'), on_time=? WHERE id=?")
    .run(onTime, r.id);
  res.json(reply(req, r.id));
});

module.exports = router;
