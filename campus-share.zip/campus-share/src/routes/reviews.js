const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');
const { computeTrust } = require('../trust');

const router = express.Router();
router.use(requireAuth);

// After a completed return, owner and borrower can each review the other once.
router.post('/', (req, res) => {
  const requestId = Number(req.body.requestId);
  const rating = Number(req.body.rating);
  const comment = String(req.body.comment || '').trim().slice(0, 500);

  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return res.status(400).json({ error: 'Rating must be 1 to 5 stars.' });

  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(requestId);
  if (!r) return res.status(404).json({ error: 'Request not found.' });
  if (![r.owner_id, r.borrower_id].includes(req.user.id))
    return res.status(403).json({ error: 'You were not part of this transaction.' });
  if (r.status !== 'returned')
    return res.status(409).json({ error: 'You can review only after the item is returned.' });

  const reviewee = req.user.id === r.owner_id ? r.borrower_id : r.owner_id;
  try {
    db.prepare('INSERT INTO reviews (request_id, reviewer_id, reviewee_id, rating, comment) VALUES (?, ?, ?, ?, ?)')
      .run(requestId, req.user.id, reviewee, rating, comment);
  } catch (e) {
    if (String(e.message).includes('UNIQUE'))
      return res.status(409).json({ error: 'You already reviewed this transaction.' });
    throw e;
  }
  res.status(201).json({ ok: true, revieweeTrust: computeTrust(reviewee) });
});

module.exports = router;
