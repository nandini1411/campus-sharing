const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');
const { computeTrust } = require('../trust');

const router = express.Router();
router.use(requireAuth);

router.get('/me', (req, res) => {
  const u = db.prepare('SELECT id, name, email, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  res.json({ ...u, trust: computeTrust(u.id) });
});

// Public profile: trust score + reviews received
router.get('/:id', (req, res) => {
  const u = db.prepare('SELECT id, name, created_at FROM users WHERE id = ?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  const reviews = db
    .prepare(
      `SELECT r.rating, r.comment, r.created_at, a.name AS reviewer, i.title AS item
         FROM reviews r
         JOIN users a ON a.id = r.reviewer_id
         JOIN requests q ON q.id = r.request_id
         JOIN items i ON i.id = q.item_id
        WHERE r.reviewee_id = ?
        ORDER BY r.created_at DESC LIMIT 50`
    )
    .all(u.id);
  res.json({ ...u, trust: computeTrust(u.id), reviews });
});

module.exports = router;
