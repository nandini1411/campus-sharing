const db = require('./db');

/**
 * TRUST SCORE (0-100)
 *
 *   trust = 100 * ( 0.6 * returnScore + 0.4 * reviewScore )
 *
 *   returnScore = (onTimeReturns + 1) / (completedReturns + 2)
 *       -> how reliably this person returns borrowed items on time.
 *
 *   reviewScore = ((sumOfRatings + 2.5 * 2) / (reviewCount + 2)) / 5
 *       -> average star rating received from other students.
 *
 * Both parts use Bayesian smoothing (the "+1 / +2" and "2.5 * 2" terms), so a
 * brand-new user starts at a neutral 50 and one lucky/unlucky transaction
 * cannot swing the score to an extreme.
 */
function computeTrust(userId) {
  const r = db
    .prepare(
      `SELECT COUNT(*) AS completed, COALESCE(SUM(on_time), 0) AS onTime
         FROM requests WHERE borrower_id = ? AND status = 'returned'`
    )
    .get(userId);

  const v = db
    .prepare(
      `SELECT COUNT(*) AS cnt, COALESCE(SUM(rating), 0) AS sum
         FROM reviews WHERE reviewee_id = ?`
    )
    .get(userId);

  const returnScore = (r.onTime + 1) / (r.completed + 2);
  const reviewScore = (v.sum + 2.5 * 2) / (v.cnt + 2) / 5;
  const score = Math.round(100 * (0.6 * returnScore + 0.4 * reviewScore));

  let level = 'New';
  if (r.completed + v.cnt >= 3) {
    level = score >= 80 ? 'Highly trusted' : score >= 60 ? 'Trusted' : score >= 40 ? 'Fair' : 'Low';
  }

  return {
    score,
    level,
    completedReturns: r.completed,
    onTimeReturns: r.onTime,
    reviewCount: v.cnt,
    avgRating: v.cnt ? Math.round((v.sum / v.cnt) * 10) / 10 : null,
  };
}

module.exports = { computeTrust };
