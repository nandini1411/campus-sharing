// End-to-end smoke test: runs the real Express app against a throw-away database.
// Run with:  npm test
process.env.DB_PATH = ':memory:';
process.env.ALLOWED_EMAIL_DOMAINS = 'college.edu';
process.env.JWT_SECRET = 'test';

const assert = require('assert');
const db = require('../src/db');
const app = require('../src/app');

let server, base;
async function call(method, path, token, body) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, data: await res.json() };
}
const future = (days) => new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);

(async () => {
  server = app.listen(0);
  base = `http://localhost:${server.address().port}/api`;

  // --- registration rules
  let r = await call('POST', '/auth/register', null, { name: 'Bad', email: 'x@gmail.com', password: 'secret1' });
  assert.equal(r.status, 400, 'non-college email must be rejected');

  r = await call('POST', '/auth/register', null, { name: 'Asha', email: 'asha@college.edu', password: 'secret1' });
  assert.equal(r.status, 201);
  const asha = r.data.token;
  assert.equal(r.data.user.trust.score, 50, 'new users start at 50');

  r = await call('POST', '/auth/register', null, { name: 'Ravi', email: 'ravi@cs.college.edu', password: 'secret1' });
  assert.equal(r.status, 201);
  const ravi = r.data.token;
  const raviId = r.data.user.id;

  // --- list + search
  r = await call('POST', '/items', asha, { title: 'Casio fx-991EX', category: 'Calculators' });
  assert.equal(r.status, 201);
  const itemId = r.data.id;
  r = await call('GET', '/items?q=casio', ravi);
  assert.equal(r.data.length, 1);

  // --- borrow flow
  r = await call('POST', '/requests', asha, { itemId, dueDate: future(3) });
  assert.equal(r.status, 400, "can't borrow own item");
  r = await call('POST', '/requests', ravi, { itemId, dueDate: '2000-01-01' });
  assert.equal(r.status, 400, 'past due date rejected');
  r = await call('POST', '/requests', ravi, { itemId, dueDate: future(3), message: 'exam week' });
  assert.equal(r.status, 201);
  const reqId = r.data.id;

  r = await call('POST', `/requests/${reqId}/approve`, ravi);
  assert.equal(r.status, 403, 'borrower cannot approve');
  r = await call('POST', `/requests/${reqId}/approve`, asha);
  assert.equal(r.data.status, 'approved');
  r = await call('GET', '/items/mine', asha);
  assert.equal(r.data[0].lent_out, true);

  // --- return + reviews + trust
  r = await call('POST', `/reviews`, ravi, { requestId: reqId, rating: 5 });
  assert.equal(r.status, 409, 'cannot review before return');
  r = await call('POST', `/requests/${reqId}/return`, asha);
  assert.equal(r.data.status, 'returned');
  assert.equal(r.data.on_time, 1);

  r = await call('POST', '/reviews', asha, { requestId: reqId, rating: 5, comment: 'Careful and punctual' });
  assert.equal(r.status, 201);
  r = await call('POST', '/reviews', asha, { requestId: reqId, rating: 5 });
  assert.equal(r.status, 409, 'one review per person per transaction');

  r = await call('GET', '/users/' + raviId, asha);
  // returnScore=(1+1)/(1+2)=.667 ; reviewScore=(5+5)/(1+2)/5=.667 -> 67
  assert.equal(r.data.trust.score, 67);
  assert.equal(r.data.reviews.length, 1);

  // --- a late return lowers the score
  r = await call('POST', '/requests', ravi, { itemId, dueDate: future(2) });
  const lateId = r.data.id;
  await call('POST', `/requests/${lateId}/approve`, asha);
  db.prepare("UPDATE requests SET due_date = date('now','-5 days') WHERE id = ?").run(lateId);
  r = await call('GET', '/requests?view=incoming', asha);
  assert.equal(r.data[0].overdue, true, 'overdue flag set');
  r = await call('POST', `/requests/${lateId}/return`, asha);
  assert.equal(r.data.on_time, 0);
  r = await call('GET', '/users/' + raviId, asha);
  assert.ok(r.data.trust.score < 67, 'late return lowers trust');

  // --- history
  r = await call('GET', '/requests?view=history', ravi);
  assert.equal(r.data.length, 2);

  console.log('All smoke tests passed ✅');
  server.close();
})().catch((e) => { console.error('FAILED:', e); process.exit(1); });
